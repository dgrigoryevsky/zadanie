<?
$MESS["ZADANIE_CURRENCY_MODULE_NAME"] = "Курсы валют ЦБ РФ";
$MESS["ZADANIE_CURRENCY_MODULE_DESC"] = "Модуль для загрузки и отображения актуальных курсов валют ЦБ РФ";
$MESS["ZADANIE_CURRENCY_INSTALL_TITLE"] = "Установка модуля \"Курсы валют ЦБ РФ\"";
$MESS["ZADANIE_CURRENCY_UNINSTALL_TITLE"] = "Удаление модуля \"Курсы валют ЦБ РФ\"";
$MESS["ZADANIE_CURRENCY_INSTALL_ERROR_VERSION"] = "Версия главного модуля ниже 20.0.0. Не поддерживается.";
?>