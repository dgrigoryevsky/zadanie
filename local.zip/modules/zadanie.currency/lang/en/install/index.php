<?php
$MESS["ZADANIE_CURRENCY_MODULE_NAME"] = "Central Bank Currency Rates";
$MESS["ZADANIE_CURRENCY_MODULE_DESC"] = "Module for loading and displaying current CBR currency rates";
$MESS["ZADANIE_CURRENCY_INSTALL_TITLE"] = "Install \"Central Bank Currency Rates\" module";
$MESS["ZADANIE_CURRENCY_UNINSTALL_TITLE"] = "Uninstall \"Central Bank Currency Rates\" module";
$MESS["ZADANIE_CURRENCY_INSTALL_ERROR_VERSION"] = "Main module version is lower than 20.0.0. Not supported.";
?>