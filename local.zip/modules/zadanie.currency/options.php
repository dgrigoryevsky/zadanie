<?
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\HttpApplication;
use Bitrix\Main\Loader;
use Bitrix\Main\Config\Option;

$module_id = 'zadanie.currency';

Loc::loadMessages($_SERVER["DOCUMENT_ROOT"].BX_ROOT."/modules/main/options.php");
Loc::loadMessages(__FILE__);

if (!$USER->isAdmin())
    $APPLICATION->authForm('Nope');

$app = HttpApplication::getInstance();
$context = $app->getContext();
$request = $context->getRequest();

$aTabs = array(
    array(
        "DIV" => "edit1",
        "TAB" => "Основные настройки",
        "TITLE" => "Настройки модуля курсов валют"
    ),
);

$tabControl = new CAdminTabControl("tabControl", $aTabs);

if ($request->isPost() && $request['save'] && check_bitrix_sessid()) {
    $oldInterval = Option::get($module_id, "UPDATE_INTERVAL", "86400");
    $newInterval = intval($request->getPost('UPDATE_INTERVAL'));
    
    // Валидация интервала (минимум 1 час, максимум 7 дней)
    if ($newInterval < 3600) {
        $newInterval = 3600;
        $APPLICATION->ThrowException("Минимальный интервал обновления: 1 час (3600 секунд)");
    } elseif ($newInterval > 604800) {
        $newInterval = 604800;
        $APPLICATION->ThrowException("Максимальный интервал обновления: 7 дней (604800 секунд)");
    }
    
    // Сохраняем настройки
    Option::set($module_id, "UPDATE_INTERVAL", $newInterval);
    Option::set($module_id, "TIMEOUT", $request->getPost('TIMEOUT'));
    Option::set($module_id, "ENABLE_LOGGING", $request->getPost('ENABLE_LOGGING') ? 'Y' : 'N');
    
    // Если интервал изменился, обновляем агент
    if ($oldInterval != $newInterval) {
        updateAgentInterval($newInterval);
        
        if ($GLOBALS['APPLICATION']->GetException()) {
            // Если есть ошибки валидации, не показываем сообщение об успехе
        } else {
            CAdminMessage::ShowMessage(array(
                "TYPE" => "OK",
                "MESSAGE" => "Настройки сохранены",
                "DETAILS" => "Интервал обновления агента изменен на " . formatInterval($newInterval),
                "HTML" => true
            ));
        }
    } else {
        if (!$GLOBALS['APPLICATION']->GetException()) {
            CAdminMessage::ShowMessage(array(
                "TYPE" => "OK", 
                "MESSAGE" => "Настройки сохранены",
                "HTML" => true
            ));
        }
    }
}

/**
 * Обновляет интервал выполнения агента
 */
function updateAgentInterval($newInterval) {
    global $APPLICATION;
    
    // Находим текущий агент
    $agentIterator = CAgent::GetList(
        array(), 
        array(
            "MODULE_ID" => "zadanie.currency",
            "NAME" => "\\Zadanie\\Currency\\Agent::updateCurrencyRates();"
        )
    );
    
    if ($agent = $agentIterator->Fetch()) {
        // Удаляем старый агент
        CAgent::Delete($agent['ID']);
        
        // Создаем новый агент с обновленным интервалом
        $agentId = CAgent::AddAgent(
            "\\Zadanie\\Currency\\Agent::updateCurrencyRates();",
            "zadanie.currency",
            "N",
            $newInterval,
            "",
            "Y",
            "",
            100
        );
        
        if (!$agentId) {
            $APPLICATION->ThrowException("Ошибка при обновлении агента");
            return false;
        }
        
        return true;
    } else {
        // Если агент не найден, создаем новый
        $agentId = CAgent::AddAgent(
            "\\Zadanie\\Currency\\Agent::updateCurrencyRates();",
            "zadanie.currency", 
            "N",
            $newInterval,
            "",
            "Y",
            "",
            100
        );
        
        if (!$agentId) {
            $APPLICATION->ThrowException("Ошибка при создании агента");
            return false;
        }
        
        return true;
    }
}

/**
 * Форматирует интервал в читаемый вид
 */
function formatInterval($seconds) {
    if ($seconds >= 86400) {
        $days = floor($seconds / 86400);
        $hours = floor(($seconds % 86400) / 3600);
        return $days . " дн." . ($hours > 0 ? " " . $hours . " ч." : "");
    } elseif ($seconds >= 3600) {
        $hours = floor($seconds / 3600);
        $minutes = floor(($seconds % 3600) / 60);
        return $hours . " ч." . ($minutes > 0 ? " " . $minutes . " мин." : "");
    } else {
        $minutes = floor($seconds / 60);
        return $minutes . " мин." . ($seconds % 60 > 0 ? " " . ($seconds % 60) . " сек." : "");
    }
}

$UPDATE_INTERVAL = Option::get($module_id, "UPDATE_INTERVAL", "86400");
$TIMEOUT = Option::get($module_id, "TIMEOUT", "30");
$ENABLE_LOGGING = Option::get($module_id, "ENABLE_LOGGING", "Y");

// Получаем информацию о текущем агенте
$currentAgent = null;
$agentIterator = CAgent::GetList(
    array(), 
    array(
        "MODULE_ID" => "zadanie.currency",
        "NAME" => "\\Zadanie\\Currency\\Agent::updateCurrencyRates();"
    )
);
if ($agent = $agentIterator->Fetch()) {
    $currentAgent = $agent;
}
?>

<form method="post" action="<?echo $APPLICATION->GetCurPage()?>?mid=<?=urlencode($module_id)?>&amp;lang=<?echo LANGUAGE_ID?>">
    <?php
    $tabControl->Begin();
    $tabControl->BeginNextTab();
    ?>
    
    <tr>
        <td width="40%" class="adm-detail-content-cell-l">
            <label for="UPDATE_INTERVAL">Интервал обновления (сек):</label>
        </td>
        <td width="60%" class="adm-detail-content-cell-r">
            <input type="number" 
                   id="UPDATE_INTERVAL" 
                   name="UPDATE_INTERVAL" 
                   value="<?=htmlspecialchars($UPDATE_INTERVAL)?>" 
                   min="3600" 
                   max="604800" 
                   step="60" />
            <br><small style="color: #666;">
                Минимум: 1 час (3600 сек), Максимум: 7 дней (604800 сек)<br>
                Текущий интервал: <strong><?=formatInterval($UPDATE_INTERVAL)?></strong>
            </small>
        </td>
    </tr>
    
    <tr>
        <td width="40%" class="adm-detail-content-cell-l">
            <label for="TIMEOUT">Таймаут запроса (сек):</label>
        </td>
        <td width="60%" class="adm-detail-content-cell-r">
            <input type="number" 
                   id="TIMEOUT" 
                   name="TIMEOUT" 
                   value="<?=htmlspecialchars($TIMEOUT)?>" 
                   min="5" 
                   max="300" />
            <br><small style="color: #666;">От 5 до 300 секунд</small>
        </td>
    </tr>
    
    <tr>
        <td width="40%" class="adm-detail-content-cell-l">
            <label for="ENABLE_LOGGING">Включить логирование:</label>
        </td>
        <td width="60%" class="adm-detail-content-cell-r">
            <input type="checkbox" 
                   id="ENABLE_LOGGING" 
                   name="ENABLE_LOGGING" 
                   value="Y" 
                   <?=($ENABLE_LOGGING=="Y" ? "checked" : "")?> />
            <br><small style="color: #666;">Записывать операции в лог-файл</small>
        </td>
    </tr>
    
    <?php if ($currentAgent): ?>
    <tr>
        <td width="40%" class="adm-detail-content-cell-l">
            <strong>Информация об агенте:</strong>
        </td>
        <td width="60%" class="adm-detail-content-cell-r">
            <div style="background: #f0f8ff; border: 1px solid #d0e4f7; padding: 10px; border-radius: 3px;">
                <strong>ID агента:</strong> <?=$currentAgent['ID']?><br>
                <strong>Интервал:</strong> <?=formatInterval($currentAgent['AGENT_INTERVAL'])?><br>
                <strong>Последнее выполнение:</strong> 
                <?=($currentAgent['LAST_EXEC'] ? $currentAgent['LAST_EXEC'] : 'Не выполнялся')?><br>
                <strong>Следующее выполнение:</strong> 
                <?=($currentAgent['NEXT_EXEC'] ? $currentAgent['NEXT_EXEC'] : 'Не запланировано')?><br>
                <strong>Активен:</strong> <?=($currentAgent['ACTIVE'] == 'Y' ? 'Да' : 'Нет')?>
            </div>
        </td>
    </tr>
    <?php else: ?>
    <tr>
        <td width="40%" class="adm-detail-content-cell-l">
            <strong>Статус агента:</strong>
        </td>
        <td width="60%" class="adm-detail-content-cell-r">
            <div style="background: #fff0f0; border: 1px solid #f7d0d0; padding: 10px; border-radius: 3px; color: #d00;">
                <strong>Агент не найден!</strong> Будет создан при сохранении настроек.
            </div>
        </td>
    </tr>
    <?php endif; ?>
    
    <tr>
        <td colspan="2" class="adm-detail-content-cell-l">
            <div style="background: #f9f9f9; border: 1px solid #ddd; padding: 15px; border-radius: 3px; margin-top: 15px;">
                <h4 style="margin-top: 0;">Рекомендуемые настройки:</h4>
                <ul style="margin: 10px 0; padding-left: 20px;">
                    <li><strong>Для продакшена:</strong> 86400 сек (24 часа) - стандартное обновление</li>
                    <li><strong>Для разработки:</strong> 3600 сек (1 час) - частое обновление для тестов</li>
                    <li><strong>Для высоконагруженных сайтов:</strong> 43200 сек (12 часов) - снижение нагрузки</li>
                </ul>
                <p style="color: #666; font-size: 0.9em; margin-bottom: 0;">
                    <strong>Примечание:</strong> ЦБ РФ обновляет курсы валют ежедневно около 15:00 МСК. 
                    Слишком частые запросы не принесут пользы.
                </p>
            </div>
        </td>
    </tr>
    
    <?php
    $tabControl->Buttons();
    ?>
    <input type="submit" name="save" value="Сохранить" class="adm-btn-save" />
    <input type="reset" name="reset" value="Сбросить" />
    <input type="button" value="Обновить курсы сейчас" onclick="forceUpdateRates()" class="adm-btn" />
    <?=bitrix_sessid_post();?>
    
    <?php
    $tabControl->End();
    ?>
</form>

<script>
function forceUpdateRates() {
    if (confirm('Принудительно обновить курсы валют?')) {
        BX.ajax.runAction('', {
            data: {
                action: 'force_update',
                sessid: BX.bitrix_sessid()
            }
        }).then(function(response) {
            if (response.data && response.data.success) {
                alert('Курсы валют успешно обновлены!\nОбновлено валют: ' + response.data.updated);
                location.reload();
            } else {
                alert('Ошибка при обновлении курсов: ' + (response.data ? response.data.error : 'Неизвестная ошибка'));
            }
        }).catch(function(error) {
            // Fallback - перезагружаем агент напрямую
            window.open('/local/modules/zadanie.currency/admin/force_update.php', '_blank', 'width=600,height=400');
        });
    }
}

// Автоматический пересчет отображения интервала
document.getElementById('UPDATE_INTERVAL').addEventListener('input', function() {
    const seconds = parseInt(this.value);
    const preview = this.parentNode.querySelector('small');
    let formatted = '';
    
    if (seconds >= 86400) {
        const days = Math.floor(seconds / 86400);
        const hours = Math.floor((seconds % 86400) / 3600);
        formatted = days + ' дн.' + (hours > 0 ? ' ' + hours + ' ч.' : '');
    } else if (seconds >= 3600) {
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        formatted = hours + ' ч.' + (minutes > 0 ? ' ' + minutes + ' мин.' : '');
    } else if (seconds >= 60) {
        const minutes = Math.floor(seconds / 60);
        formatted = minutes + ' мин.' + (seconds % 60 > 0 ? ' ' + (seconds % 60) + ' сек.' : '');
    } else {
        formatted = seconds + ' сек.';
    }
    
    preview.innerHTML = 'Минимум: 1 час (3600 сек), Максимум: 7 дней (604800 сек)<br>Новый интервал: <strong>' + formatted + '</strong>';
});
</script>