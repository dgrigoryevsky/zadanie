<?php
namespace Zadanie\Currency;
use Bitrix\Main\Loader;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Web\HttpClient;
use Bitrix\Main\Application;

class Agent{
    public static function updateCurrencyRates(){
        if (!Loader::includeModule('zadanie.currency') || !Loader::includeModule('iblock')){
            return "\\Zadanie\\Currency\\Agent::updateCurrencyRates();";
        }
        $currencyService = new CurrencyService();
        $result = $currencyService->updateRates();
        
        // Логирование результата
        if ($result['success']){
            AddMessage2Log("Курсы валют были успешно обновлены: " . $result['updated'], "zadanie.currency");
        }else{
            AddMessage2Log("Ошибка в обновлении курсов валют: " . $result['error'], "zadanie.currency", "ERROR");
        }

        return "\\Zadanie\\Currency\\Agent::updateCurrencyRates();";
    }
}
?>