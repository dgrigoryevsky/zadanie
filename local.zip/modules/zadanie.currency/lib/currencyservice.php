<?namespace Zadanie\Currency;

use Bitrix\Main\Config\Option;
use Bitrix\Main\Web\HttpClient;
use Bitrix\Main\Loader;

class CurrencyService{
    const CBR_API_URL = 'https://www.cbr-xml-daily.ru/daily.xml';
    const SOAP_URL = 'https://www.cbr.ru/DailyInfoWebServ/DailyInfo.asmx?WSDL';
    
    private $iblockId;
    private $httpClient;
    
    public function __construct(){
        $this->iblockId = Option::get('zadanie.currency', 'CURRENCY_IBLOCK_ID');
        $this->httpClient = new HttpClient([
            'timeout' => intval(Option::get('zadanie.currency', 'TIMEOUT', '30')),
            'waitResponse' => true
        ]);
    }
    
    public function updateRates(){
        try {
            // Пытаемся получить данные через REST API
            $data = $this->fetchDataRest();
            
            if (!$data) {
                // Если REST не сработал, пробуем SOAP
                $data = $this->fetchDataSoap();
            }
            
            if (!$data) {
                throw new \Exception('Не получилось получить данные ни через REST, ни через SOAP');
            }
            
            $updated = $this->saveCurrencyData($data);
            
            // Логируем успешное обновление
            if (Option::get('zadanie.currency', 'ENABLE_LOGGING', 'Y') === 'Y') {
                AddMessage2Log("Курс валют был обновлению. Обновлено: " . $updated, "zadanie.currency");
            }
            
            return [
                'success' => true,
                'updated' => $updated,
                'data' => $data
            ];
            
        } catch (\Exception $e) {
            // Логируем ошибку
            if (Option::get('zadanie.currency', 'ENABLE_LOGGING', 'Y') === 'Y') {
                AddMessage2Log("Обновление курса прошло с ошибкой: " . $e->getMessage(), "zadanie.currency", "ERROR");
            }
            
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    private function fetchDataRest()
    {
        try {
            $response = $this->httpClient->get(self::CBR_API_URL);
            
            if (!$response) {
                throw new \Exception('HTTP запрос с ошибкой');
            }
            
            // Проверяем статус ответа
            $status = $this->httpClient->getStatus();
            if ($status !== 200) {
                throw new \Exception('HTTP статус: ' . $status);
            }
            
            $xml = simplexml_load_string($response);
            
            if (!$xml) {
                throw new \Exception('Неверный XML ответ');
            }
            
            return $this->parseXmlData($xml);
            
        } catch (\Exception $e) {
            if (Option::get('zadanie.currency', 'ENABLE_LOGGING', 'Y') === 'Y') {
                AddMessage2Log("REST API ошибка: " . $e->getMessage(), "zadanie.currency", "ERROR");
            }
            return false;
        }
    }
    
    private function fetchDataSoap()
    {
        try {
            if (!class_exists('SoapClient')) {
                throw new \Exception('SOAP не доступен');
            }
            
            $client = new \SoapClient(self::SOAP_URL, [
                'connection_timeout' => intval(Option::get('zadanie.currency', 'TIMEOUT', '30')),
                'cache_wsdl' => WSDL_CACHE_NONE
            ]);
            
            $date = new \DateTime();
            $response = $client->GetCursOnDate(['On_date' => $date->format('Y-m-d\TH:i:s')]);
            
            if (!$response) {
                throw new \Exception('SOAP запрос выдал ошибку');
            }
            
            return $this->parseSoapData($response);
            
        } catch (\Exception $e) {
            if (Option::get('zadanie.currency', 'ENABLE_LOGGING', 'Y') === 'Y') {
                AddMessage2Log("SOAP API ошибка: " . $e->getMessage(), "zadanie.currency", "ERROR");
            }
            return false;
        }
    }
    
    private function parseXmlData($xml)
    {
        $currencies = [];
        $date = (string)$xml['Date'];
        
        foreach ($xml->Valute as $valute) {
            $currencies[] = [
                'code' => (string)$valute->CharCode,
                'name' => (string)$valute->Name,
                'nominal' => (int)$valute->Nominal,
                'value' => (float)str_replace(',', '.', (string)$valute->Value),
                'previous' => (float)str_replace(',', '.', (string)$valute->Previous),
                'date' => $date
            ];
        }
        
        return $currencies;
    }
    
    private function parseSoapData($soapResponse)
    {
        $currencies = [];
        
        if (isset($soapResponse->GetCursOnDateResult->any)) {
            $xml = simplexml_load_string($soapResponse->GetCursOnDateResult->any);
            return $this->parseXmlData($xml);
        }
        
        return $currencies;
    }
    
    private function saveCurrencyData($currencies){
        if (!Loader::includeModule('iblock')) {
            throw new \Exception('Не загрузили модуль инфоблоков');
        }
        
        $iblock = new \CIBlockElement();
        $updated = 0;
        
        foreach ($currencies as $currency) {
            // Проверяем, существует ли уже элемент с таким кодом валюты
            $existingElement = \CIBlockElement::GetList(
                [],
                [
                    'IBLOCK_ID' => $this->iblockId,
                    'PROPERTY_CURRENCY_CODE' => $currency['code'],
                    'ACTIVE' => 'Y'
                ],
                false,
                ['nTopCount' => 1],
                ['ID', 'NAME', 'PROPERTY_CURRENCY_CODE', 'PROPERTY_VALUE']
            )->GetNext();
            
            $arFields = [
                'IBLOCK_ID' => $this->iblockId,
                'NAME' => $currency['name'],
                'ACTIVE' => 'Y',
                'PROPERTY_VALUES' => [
                    'CURRENCY_CODE' => $currency['code'],
                    'NOMINAL' => $currency['nominal'],
                    'VALUE' => $currency['value'],
                    'PREVIOUS' => $currency['previous']
                ]
            ];
            
            if ($existingElement) {
                $currentValue = (float)($existingElement['PROPERTY_VALUE_VALUE'] ?? 0);
				$arFields['PROPERTY_VALUES']['PREVIOUS'] = $currentValue;
                
                // Обновляем существующий элемент
                if ($iblock->Update($existingElement['ID'], $arFields)) {
                    $updated++;
                } else {
                    if (Option::get('zadanie.currency', 'ENABLE_LOGGING', 'Y') === 'Y') {
                        AddMessage2Log("Ошибка обновления курса " . $currency['code'] . ": " . $iblock->LAST_ERROR, "zadanie.currency", "ERROR");
                    }
                }
            } else {
                // Создаем новый элемент
                if ($iblock->Add($arFields)) {
                    $updated++;
                } else {
                    if (Option::get('zadanie.currency', 'ENABLE_LOGGING', 'Y') === 'Y') {
                        AddMessage2Log("Ошибка добавления курса " . $currency['code'] . ": " . $iblock->LAST_ERROR, "zadanie.currency", "ERROR");
                    }
                }
            }
        }
        
        return $updated;
    }
    
    public function getCurrencyRate($currencyCode){
        if (!Loader::includeModule('iblock')) {
            return false;
        }
        
        $rsElement = \CIBlockElement::GetList(
            [],
            [
                'IBLOCK_ID' => $this->iblockId,
                'PROPERTY_CURRENCY_CODE' => $currencyCode,
                'ACTIVE' => 'Y'
            ],
            false,
            ['nTopCount' => 1],
            [
                'ID', 
                'NAME',
                'PROPERTY_CURRENCY_CODE',
                'PROPERTY_NOMINAL',
                'PROPERTY_VALUE',
                'PROPERTY_PREVIOUS'
            ]
        );
        
        if ($arElement = $rsElement->GetNext()) {
            return [
                'id' => $arElement['ID'],
                'name' => $arElement['NAME'],
                'code' => $arElement['PROPERTY_CURRENCY_CODE_VALUE'] ?? '',
                'nominal' => (int)($arElement['PROPERTY_NOMINAL_VALUE'] ?? 1),
                'value' => (float)($arElement['PROPERTY_VALUE_VALUE'] ?? 0),
                'previous' => (float)($arElement['PROPERTY_PREVIOUS_VALUE'] ?? 0)
            ];
        }
        
        return false;
    }
    
    public function getAllCurrencies(){
        if (!Loader::includeModule('iblock')) {
            return [];
        }
        
        $rsElements = \CIBlockElement::GetList(
            ['NAME' => 'ASC'],
            ['IBLOCK_ID' => $this->iblockId, 'ACTIVE' => 'Y'],
            false,
            false,
            [
                'ID', 
                'NAME',
                'PROPERTY_CURRENCY_CODE',
                'PROPERTY_NOMINAL',
                'PROPERTY_VALUE', 
                'PROPERTY_PREVIOUS'
            ]
        );
        
        $currencies = [];
        
        while ($arElement = $rsElements->GetNext()) {
            $currencyData = [
                'ID' => $arElement['ID'],
                'NAME' => $arElement['NAME'],
                'CODE' => $arElement['PROPERTY_CURRENCY_CODE_VALUE'] ?? '',
                'NOMINAL' => (int)($arElement['PROPERTY_NOMINAL_VALUE'] ?? 1),
                'VALUE' => (float)($arElement['PROPERTY_VALUE_VALUE'] ?? 0),
                'PREVIOUS' => (float)($arElement['PROPERTY_PREVIOUS_VALUE'] ?? 0),
            ];
            
            $currencyData['CHANGE'] = round($currencyData['VALUE'] - $currencyData['PREVIOUS'], 4);
            
            $currencies[] = $currencyData;
        }
        
        return $currencies;
    }
    
    public function getCurrenciesByCodes($codes = []){
        if (empty($codes)) {
            return $this->getAllCurrencies();
        }
        
        if (!Loader::includeModule('iblock')) {
            return [];
        }
        
        $currencies = [];
        
        foreach ($codes as $code) {
            $currency = $this->getCurrencyRate($code);
            if ($currency) {
                $currency['CHANGE'] = round($currency['value'] - $currency['previous'], 4);
                $currencies[] = $currency;
            }
        }
        
        return $currencies;
    }
}?>