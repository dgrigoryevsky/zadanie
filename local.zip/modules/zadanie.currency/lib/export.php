<?
namespace Zadanie\Currency;
use Bitrix\Main\Loader;
use Bitrix\Main\Config\Option;

class Export {
    private $iblockId;
    
    public function __construct() {
        $this->iblockId = Option::get('zadanie.currency', 'CURRENCY_IBLOCK_ID');
    }
    
    public function exportToArray() {
        if (!Loader::includeModule('iblock') || !$this->iblockId) {
            return false;
        }
        
        $currencies = [];
        
        // Используем стабильно работающий способ
        $rsElements = \CIBlockElement::GetList(
            ['NAME' => 'ASC'],
            ['IBLOCK_ID' => $this->iblockId, 'ACTIVE' => 'Y'],
            false,
            false,
            [
                'ID', 
                'NAME',
                'PROPERTY_CURRENCY_CODE',
                'PROPERTY_NOMINAL',
                'PROPERTY_VALUE', 
                'PROPERTY_PREVIOUS'
            ]
        );
        
        while ($arElement = $rsElements->GetNext()) {
            $currencies[] = [
                'id' => $arElement['ID'],
                'name' => $arElement['NAME'],
                'code' => $arElement['PROPERTY_CURRENCY_CODE_VALUE'] ?? '',
                'nominal' => (float)($arElement['PROPERTY_NOMINAL_VALUE'] ?? 1),
                'value' => (float)($arElement['PROPERTY_VALUE_VALUE'] ?? 0),
                'previous' => (float)($arElement['PROPERTY_PREVIOUS_VALUE'] ?? 0),
                'change' => round(
                    (float)($arElement['PROPERTY_VALUE_VALUE'] ?? 0) - 
                    (float)($arElement['PROPERTY_PREVIOUS_VALUE'] ?? 0), 
                    4
                )
            ];
        }
        
        return $currencies;
    }
    
    public function exportToJson() {
        $currencies = $this->exportToArray();
        
        if ($currencies === false) {
            return json_encode(['error' => 'Не удалось загрузить модуль инфоблоков или получить ID инфоблока'], JSON_UNESCAPED_UNICODE);
        }
        
        return json_encode([
            'export_date' => date('c'),
            'total_count' => count($currencies),
            'currencies' => $currencies
        ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    }
    
    public function exportToXml() {
        $currencies = $this->exportToArray();
        
        if ($currencies === false) {
            return '<?xml version="1.0" encoding="UTF-8"?><error>Не удалось загрузить модуль инфоблоков или получить ID инфоблока</error>';
        }
        
        $xml = new \DOMDocument('1.0', 'UTF-8');
        $xml->formatOutput = true;
        
        $root = $xml->createElement('export');
        $root->setAttribute('date', date('c'));
        $root->setAttribute('count', count($currencies));
        $xml->appendChild($root);
        
        $currenciesNode = $xml->createElement('currencies');
        $root->appendChild($currenciesNode);
        
        foreach ($currencies as $currency) {
            $currencyNode = $xml->createElement('currency');
            
            foreach ($currency as $key => $value) {
                $value = htmlspecialchars((string)$value, ENT_XML1, 'UTF-8');
                $currencyNode->setAttribute($key, $value);
            }
            
            $currenciesNode->appendChild($currencyNode);
        }
        
        return $xml->saveXML();
    }
    
    public function exportToCsv() {
        $currencies = $this->exportToArray();
        
        if ($currencies === false) {
            return "\xEF\xBB\xBF" . "Ошибка;Не удалось загрузить модуль инфоблоков или получить ID инфоблока\n";
        }
        
        $csv = "ID;Код;Название;Номинал;Курс;Предыдущий;Изменение\n";
        
        foreach ($currencies as $currency) {
            $csv .= sprintf(
                "%s;%s;%s;%s;%s;%s;%s\n",
                $currency['id'],
                $currency['code'],
                str_replace([';', "\r", "\n"], [',', ' ', ' '], $currency['name']),
                $currency['nominal'],
                $currency['value'],
                $currency['previous'],
                $currency['change']
            );
        }
        
        return "\xEF\xBB\xBF" . $csv;
    }
    
    public function debug() {
        if (!Loader::includeModule('iblock')) {
            return ['error' => 'Модуль инфоблоков не загружен'];
        }
        
        $debug = [];
        $debug['iblock_id'] = $this->iblockId;
        
        if (!$this->iblockId) {
            $debug['error'] = 'ID инфоблока не настроен в опциях модуля';
            return $debug;
        }
        
        // Проверяем существование инфоблока
        $rsIblock = \CIBlock::GetByID($this->iblockId);
        if ($arIblock = $rsIblock->GetNext()) {
            $debug['iblock_exists'] = true;
            $debug['iblock_name'] = $arIblock['NAME'];
        } else {
            $debug['iblock_exists'] = false;
            $debug['error'] = 'Инфоблок с ID ' . $this->iblockId . ' не существует';
            return $debug;
        }
        
        // Получаем свойства инфоблока
        $rsProps = \CIBlockProperty::GetList(
            [],
            ['IBLOCK_ID' => $this->iblockId, 'ACTIVE' => 'Y']
        );
        
        $debug['properties'] = [];
        while ($arProp = $rsProps->GetNext()) {
            $debug['properties'][] = [
                'code' => $arProp['CODE'],
                'name' => $arProp['NAME'],
                'type' => $arProp['PROPERTY_TYPE']
            ];
        }
        
        // Тестируем получение элементов
        $testElements = $this->exportToArray();
        $debug['elements_count'] = is_array($testElements) ? count($testElements) : 0;
        $debug['sample_element'] = is_array($testElements) && !empty($testElements) ? $testElements[0] : null;
        
        return $debug;
    }
}