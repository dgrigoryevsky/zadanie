<?php
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\ModuleManager;
use Bitrix\Main\Config\Option;
use Bitrix\Main\Loader;
use Bitrix\Iblock\IblockTable;

Loc::loadMessages(__FILE__);

class zadanie_currency extends CModule {
    var $MODULE_ID = 'zadanie.currency';
    var $MODULE_VERSION;
    var $MODULE_VERSION_DATE;
    var $MODULE_NAME;
    var $MODULE_DESCRIPTION;
    var $PARTNER_NAME;
    var $PARTNER_URI;

    function __construct() {
        $arModuleVersion = array();
        include(dirname(__FILE__)."/version.php");
        $this->MODULE_VERSION = $arModuleVersion["VERSION"];
        $this->MODULE_VERSION_DATE = $arModuleVersion["VERSION_DATE"];
        $this->MODULE_NAME = Loc::getMessage("ZADANIE_CURRENCY_MODULE_NAME");
        $this->MODULE_DESCRIPTION = Loc::getMessage("ZADANIE_CURRENCY_MODULE_DESC");
        $this->PARTNER_NAME = "Dmitriy Grigoryevsky";
        $this->PARTNER_URI = "https://cosmeticvia.ru";
    }

    function DoInstall(){
        global $APPLICATION;
        
        if(CheckVersion(ModuleManager::getVersion("main"), "20.0.0")){
            $this->InstallFiles();
            $this->InstallDB();
            ModuleManager::registerModule($this->MODULE_ID);
            $this->InstallAgents();
        }else{
            $APPLICATION->ThrowException(Loc::getMessage("ZADANIE_CURRENCY_INSTALL_ERROR_VERSION"));
        }

        $APPLICATION->IncludeAdminFile(Loc::getMessage("ZADANIE_CURRENCY_INSTALL_TITLE"), $this->GetPath()."/install/step.php");
    }

    function DoUninstall(){
        global $APPLICATION;
        
        $this->UnInstallAgents();
        $this->UnInstallDB();
        $this->UnInstallFiles();
        ModuleManager::unRegisterModule($this->MODULE_ID);

        $APPLICATION->IncludeAdminFile(Loc::getMessage("ZADANIE_CURRENCY_UNINSTALL_TITLE"), $this->GetPath()."/install/unstep.php");
    }

    function InstallDB(){
        // Создание инфоблока курсов валют
        if (Loader::includeModule('iblock')){
            $iblockType = new CIBlockType();
            $arFields = array(
                'ID' => 'currency_rates',
                'SECTIONS' => 'N',
                'LANG' => array(
                    'ru' => array(
                        'NAME' => 'Курсы валют',
                        'SECTION_NAME' => 'Разделы',
                        'ELEMENT_NAME' => 'Валюты'
                    ),
                    'en' => array(
                        'NAME' => 'Currency Rates',
                        'SECTION_NAME' => 'Sections',
                        'ELEMENT_NAME' => 'Currencies'
                    )
                )
            );
            $iblockType->Add($arFields);

            $iblock = new CIBlock();
            $arFields = array(
                'ACTIVE' => 'Y',
                'NAME' => 'Курсы валют ЦБ РФ',
                'CODE' => 'currency_rates_cbr',
                'IBLOCK_TYPE_ID' => 'currency_rates',
                'SITE_ID' => 's1',
                'SORT' => 500,
                'GROUP_ID' => array(2 => 'R'),
            );
            $iblockId = $iblock->Add($arFields);

            if ($iblockId > 0){
                Option::set($this->MODULE_ID, "CURRENCY_IBLOCK_ID", $iblockId);
                $this->CreateIblockProperties($iblockId);
            }
        }
    }

    function CreateIblockProperties($iblockId){
        $property = new CIBlockProperty();
        
        // Свойства для хранения данных валют
        $properties = array(
            array(
                'NAME' => 'Код валюты',
                'CODE' => 'CURRENCY_CODE',
                'PROPERTY_TYPE' => 'S',
                'USER_TYPE' => '',
                'SORT' => 1
            ),
            array(
                'NAME' => 'Номинал',
                'CODE' => 'NOMINAL',
                'PROPERTY_TYPE' => 'N',
                'USER_TYPE' => '',
                'SORT' => 2
            ),
            array(
                'NAME' => 'Курс',
                'CODE' => 'VALUE',
                'PROPERTY_TYPE' => 'N',
                'USER_TYPE' => '',
                'SORT' => 3
            ),
            array(
                'NAME' => 'Предыдущий курс',
                'CODE' => 'PREVIOUS',
                'PROPERTY_TYPE' => 'N',
                'USER_TYPE' => '',
                'SORT' => 4
            )
        );
        foreach ($properties as $prop){
            $arFields = array_merge($prop, array(
                'IBLOCK_ID' => $iblockId,
                'ACTIVE' => 'Y',
                'MULTIPLE' => 'N',
                'IS_REQUIRED' => 'N',
                'SEARCHABLE' => 'N',
                'FILTRABLE' => 'Y',
                'SHOW_IN_LIST' => 'Y'
            ));
            $property->Add($arFields);
        }
    }
    function UnInstallDB(){
		if (Loader::includeModule('iblock')) {
			$iblockId = Option::get($this->MODULE_ID, "CURRENCY_IBLOCK_ID");
			if ($iblockId > 0){
				CIBlock::Delete($iblockId);
			}
			Option::delete($this->MODULE_ID);
		}
    }
    function InstallFiles(){
        CopyDirFiles($this->GetPath()."/install/components", $_SERVER["DOCUMENT_ROOT"]."/local/components", true, true);
    }
    function UnInstallFiles(){
        DeleteDirFiles($this->GetPath()."/install/components/", $_SERVER["DOCUMENT_ROOT"]."/local/components/");
    }
	// обновляться будет раз в сутки
    function InstallAgents(){
        CAgent::AddAgent("\\Zadanie\\Currency\\Agent::updateCurrencyRates();", $this->MODULE_ID, "N", 86400, "", "Y");
    }
    function UnInstallAgents(){
        CAgent::RemoveModuleAgents($this->MODULE_ID);
    }
    function GetPath($notDocumentRoot = false){
        if ($notDocumentRoot)
            return str_ireplace($_SERVER["DOCUMENT_ROOT"], '', dirname(__DIR__));
        else
            return dirname(__DIR__);
    }
}
?>