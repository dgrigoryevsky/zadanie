<?
echo CAdminMessage::ShowMessage(Array(
    "TYPE" => "OK", 
    "MESSAGE" => "Модуль успешно удален",
    "DETAILS" => "Модуль \"Курсы валют ЦБ РФ\" успешно удален со всеми данными.",
    "HTML" => true
));
?>