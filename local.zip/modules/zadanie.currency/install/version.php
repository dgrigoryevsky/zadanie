<?$arModuleVersion = array(
    "VERSION" => "1.0.0",
    "VERSION_DATE" => "2025-07-22 10:00:00"
);
?>