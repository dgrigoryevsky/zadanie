<?require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_before.php");

use Bitrix\Main\Loader;
use Bitrix\Main\Application;
use Zadanie\Currency\CurrencyService;

if (!Loader::includeModule('zadanie.currency')) {
    require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_after.php");
    ShowError('Модуль zadanie.currency не установлен');
    require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/epilog_admin.php");
    die();
}

$APPLICATION->SetTitle("Экспорт курсов валют");

$request = Application::getInstance()->getContext()->getRequest();

if ($request->getPost('export_format')) {
    $currencyService = new CurrencyService();
    $exportFormat = $request->getPost('export_format');
    
    if (Loader::includeModule('iblock')) {
        $iblockId = \Bitrix\Main\Config\Option::get('zadanie.currency', 'CURRENCY_IBLOCK_ID');
        
        $currencies = [];
        $rsElements = \CIBlockElement::GetList(
            ['NAME' => 'ASC'],
            ['IBLOCK_ID' => $iblockId, 'ACTIVE' => 'Y'],
            false,
            false,
            [
                'ID', 
                'NAME',
                'PROPERTY_CURRENCY_CODE',
                'PROPERTY_NOMINAL',
                'PROPERTY_VALUE', 
                'PROPERTY_PREVIOUS'
            ]
        );
        
        while ($arElement = $rsElements->GetNext()) {
            $currencies[] = [
                'id' => $arElement['ID'],
                'name' => $arElement['NAME'],
                'code' => $arElement['PROPERTY_CURRENCY_CODE_VALUE'] ?? '',
                'nominal' => (float)($arElement['PROPERTY_NOMINAL_VALUE'] ?? 1),
                'value' => (float)($arElement['PROPERTY_VALUE_VALUE'] ?? 0),
                'previous' => (float)($arElement['PROPERTY_PREVIOUS_VALUE'] ?? 0),
                'change' => round(
                    (float)($arElement['PROPERTY_VALUE_VALUE'] ?? 0) - 
                    (float)($arElement['PROPERTY_PREVIOUS_VALUE'] ?? 0), 
                    4
                )
            ];
        }
        
        switch ($exportFormat) {
            case 'json':
                exportToJson($currencies);
                break;
            case 'xml':
                exportToXml($currencies);
                break;
            case 'csv':
                exportToCsv($currencies);
                break;
            default:
                ShowError('Неизвестный формат экспорта');
        }
    }
    exit;
}

function exportToJson($currencies){
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="currency_rates_' . date('Y-m-d') . '.json"');
    
    echo json_encode([
        'date' => date('Y-m-d H:i:s'),
        'currencies' => $currencies
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}

function exportToXml($currencies){
    header('Content-Type: application/xml; charset=utf-8');
    header('Content-Disposition: attachment; filename="currency_rates_' . date('Y-m-d') . '.xml"');
    
    $xml = new DOMDocument('1.0', 'UTF-8');
    $xml->formatOutput = true;
    
    $root = $xml->createElement('CurrencyRates');
    $root->setAttribute('date', date('Y-m-d H:i:s'));
    $xml->appendChild($root);
    
    foreach ($currencies as $currency) {
        $currencyNode = $xml->createElement('Currency');
        $currencyNode->setAttribute('code', $currency['code']);
        
        $currencyNode->appendChild($xml->createElement('Name', htmlspecialchars($currency['name'])));
        $currencyNode->appendChild($xml->createElement('Nominal', $currency['nominal']));
        $currencyNode->appendChild($xml->createElement('Value', $currency['value']));
        $currencyNode->appendChild($xml->createElement('Previous', $currency['previous']));
        
        $root->appendChild($currencyNode);
    }
    
    echo $xml->saveXML();
}

function exportToCsv($currencies) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="currency_rates_' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    
    // BOM для корректного отображения в Excel
    fputs($output, "\xEF\xBB\xBF");
    
    // Заголовки
    fputcsv($output, ['Код', 'Название', 'Номинал', 'Курс', 'Предыдущий курс'], ';');
    
    foreach ($currencies as $currency) {
        fputcsv($output, [
            $currency['code'],
            $currency['name'],
            $currency['nominal'],
            $currency['value'],
            $currency['previous']
        ], ';');
    }
    
    fclose($output);
}
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_after.php");
?>
<form method="post" action="">
    <table class="adm-detail-content-table edit-table">
        <tr>
            <td class="adm-detail-content-cell-l" width="40%">
                <strong>Формат экспорта:</strong>
            </td>
            <td class="adm-detail-content-cell-r">
                <select name="export_format">
                    <option value="json">JSON</option>
                    <option value="xml">XML</option>
                    <option value="csv">CSV</option>
                </select>
            </td>
        </tr>
    </table>    
    <input type="submit" class="adm-btn-save" value="Экспортировать" />
</form>
<?php require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/epilog_admin.php"); ?>