<?php
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_before.php");

use Bitrix\Main\Loader;
use Zadanie\Currency\Agent;

if (!Loader::includeModule('zadanie.currency')) {
    ShowError('Модуль zadanie.currency не установлен');
    die();
}

$APPLICATION->SetTitle("Принудительное обновление курсов валют");

$result = null;
if ($_REQUEST['action'] == 'update') {
    $result = Agent::updateCurrencyRates();
}

require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_after.php");

if ($result): ?>
    <div class="adm-info-message-wrap adm-info-message-green">
        <div class="adm-info-message">
            <div class="adm-info-message-title">Успешно!</div>
            <div class="adm-info-message-body">
                Курсы валют обновлены. Можете закрыть это окно.
            </div>
        </div>
    </div>
    <script>
        setTimeout(function() {
            window.close();
        }, 2000);
    </script>
<?php else: ?>
    <div class="adm-info-message-wrap">
        <div class="adm-info-message">
            <div class="adm-info-message-title">Принудительное обновление курсов</div>
            <div class="adm-info-message-body">
                Нажмите кнопку для запуска обновления курсов валют вне расписания.
            </div>
        </div>
    </div>
    
    <form method="get" action="">
        <input type="hidden" name="action" value="update" />
        <input type="submit" class="adm-btn-save" value="Обновить курсы сейчас" />
        <input type="button" value="Закрыть" onclick="window.close()" />
    </form>
<?php endif;

require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/epilog_admin.php");
?>