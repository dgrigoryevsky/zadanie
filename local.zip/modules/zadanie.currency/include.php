<?
Bitrix\Main\Loader::registerAutoLoadClasses('zadanie.currency', [
    'Zadanie\\Currency\\CurrencyService' => 'lib/currencyservice.php',
    'Zadanie\\Currency\\Agent' => 'lib/agent.php',
    'Zadanie\\Currency\\Export' => 'lib/export.php',
]);
?>