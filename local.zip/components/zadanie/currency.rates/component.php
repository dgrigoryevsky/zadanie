<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

use Bitrix\Main\Loader;

// Устанавливаем значения параметров по умолчанию
if (!isset($arParams['ELEMENTS_PER_PAGE']) || intval($arParams['ELEMENTS_PER_PAGE']) <= 0) {
    $arParams['ELEMENTS_PER_PAGE'] = 20;
}

if (!isset($arParams['DEFAULT_SORT_BY']) || !in_array($arParams['DEFAULT_SORT_BY'], ['NAME', 'VALUE'])) {
    $arParams['DEFAULT_SORT_BY'] = 'NAME';
}

if (!isset($arParams['DEFAULT_SORT_ORDER']) || !in_array($arParams['DEFAULT_SORT_ORDER'], ['ASC', 'DESC'])) {
    $arParams['DEFAULT_SORT_ORDER'] = 'ASC';
}

if (!isset($arParams['SHOW_DEBUG_INFO'])) {
    $arParams['SHOW_DEBUG_INFO'] = 'N';
}

if (Loader::includeModule('iblock')) {
    $iblockId = \Bitrix\Main\Config\Option::get('zadanie.currency', 'CURRENCY_IBLOCK_ID');
    
    if ($iblockId) {
        // Параметры сортировки из GET-запроса с учетом настроек по умолчанию
        $sortBy = $_GET['sort_by'] ?? $arParams['DEFAULT_SORT_BY'];
        $sortOrder = $_GET['sort_order'] ?? $arParams['DEFAULT_SORT_ORDER'];
        
        // Валидация параметров сортировки
        $allowedSortFields = ['NAME', 'VALUE'];
        $allowedSortOrders = ['ASC', 'DESC'];
        
        if (!in_array($sortBy, $allowedSortFields)) {
            $sortBy = $arParams['DEFAULT_SORT_BY'];
        }
        
        if (!in_array($sortOrder, $allowedSortOrders)) {
            $sortOrder = $arParams['DEFAULT_SORT_ORDER'];
        }
        
        $this->arResult['SORT_BY'] = $sortBy;
        $this->arResult['SORT_ORDER'] = $sortOrder;
        $this->arResult['CURRENCIES'] = [];
        
        // Получаем все элементы
        $rsElements = \CIBlockElement::GetList(
            ['NAME' => 'ASC'],
            ['IBLOCK_ID' => $iblockId, 'ACTIVE' => 'Y'],
            false,
            false,
            [
                'ID', 
                'NAME',
                'PROPERTY_CURRENCY_CODE',
                'PROPERTY_NOMINAL',
                'PROPERTY_VALUE', 
                'PROPERTY_PREVIOUS'
            ]
        );
        
        $allCurrencies = [];
        $elementsCount = 0;
        
        // Собираем данные элементов
        while ($arElement = $rsElements->GetNext()) {
            $elementsCount++;
            
            $currencyData = [
                'ID' => $arElement['ID'],
                'NAME' => $arElement['NAME'],
                'CODE' => $arElement['PROPERTY_CURRENCY_CODE_VALUE'] ?? '',
                'NOMINAL' => (float)($arElement['PROPERTY_NOMINAL_VALUE'] ?? 1),
                'VALUE' => (float)($arElement['PROPERTY_VALUE_VALUE'] ?? 0),
                'PREVIOUS' => (float)($arElement['PROPERTY_PREVIOUS_VALUE'] ?? 0),
            ];
            
            $currencyData['CHANGE'] = round($currencyData['VALUE'] - $currencyData['PREVIOUS'], 4);
            
            $allCurrencies[] = $currencyData;
        }
        
        // Если элементы не получились, пробуем альтернативный способ
        if ($elementsCount === 0) {
            $rsElements = \CIBlockElement::GetList(
                ['NAME' => 'ASC'],
                ['IBLOCK_ID' => $iblockId, 'ACTIVE' => 'Y'],
                false,
                false,
                ['ID', 'NAME', 'PROPERTY_*']
            );
            
            while ($element = $rsElements->GetNextElement()) {
                $fields = $element->GetFields();
                $props = $element->GetProperties();
                
                $elementsCount++;
                
                $currencyData = [
                    'ID' => $fields['ID'],
                    'NAME' => $fields['NAME'],
                    'CODE' => $props['CURRENCY_CODE']['VALUE'] ?? '',
                    'NOMINAL' => (float)($props['NOMINAL']['VALUE'] ?? 1),
                    'VALUE' => (float)($props['VALUE']['VALUE'] ?? 0),
                    'PREVIOUS' => (float)($props['PREVIOUS']['VALUE'] ?? 0),
                ];
                
                $currencyData['CHANGE'] = round($currencyData['VALUE'] - $currencyData['PREVIOUS'], 4);
                
                $allCurrencies[] = $currencyData;
            }
        }
        
        // Применяем сортировку
        if ($sortBy === 'NAME') {
            usort($allCurrencies, function($a, $b) use ($sortOrder) {
                $result = strcasecmp($a['NAME'], $b['NAME']);
                return $sortOrder === 'DESC' ? -$result : $result;
            });
        } elseif ($sortBy === 'VALUE') {
            usort($allCurrencies, function($a, $b) use ($sortOrder) {
                $result = $a['VALUE'] <=> $b['VALUE'];
                return $sortOrder === 'DESC' ? -$result : $result;
            });
        }
        
        // Настройка пагинации
        $pageSize = intval($arParams['ELEMENTS_PER_PAGE']);
        $totalCount = count($allCurrencies);
        
        // Получаем номер текущей страницы
        $currentPage = intval($_GET['PAGEN_CURRENCY_NAV'] ?? 1);
        if ($currentPage < 1) $currentPage = 1;
        
        $pageCount = ceil($totalCount / $pageSize);
        if ($currentPage > $pageCount && $pageCount > 0) $currentPage = $pageCount;
        
        // Вычисляем offset и получаем элементы для текущей страницы
        $offset = ($currentPage - 1) * $pageSize;
        $this->arResult['CURRENCIES'] = array_slice($allCurrencies, $offset, $pageSize);
        
        // Сохраняем данные для навигации
        $this->arResult['ELEMENTS_COUNT'] = $totalCount;
        $this->arResult['PAGE_COUNT'] = $pageCount;
        $this->arResult['CURRENT_PAGE'] = $currentPage;
        $this->arResult['PAGE_SIZE'] = $pageSize;
        
        // Генерируем ссылки для сортировки
        $currentUrl = $GLOBALS['APPLICATION']->GetCurPage(false);
        $currentParams = $_GET;
        
        // Ссылка для сортировки по названию
        $nameParams = $currentParams;
        $nameParams['sort_by'] = 'NAME';
        $nameParams['sort_order'] = ($sortBy === 'NAME' && $sortOrder === 'ASC') ? 'DESC' : 'ASC';
        unset($nameParams['PAGEN_CURRENCY_NAV']); // Сброс пагинации при смене сортировки
        
        // Ссылка для сортировки по курсу
        $valueParams = $currentParams;
        $valueParams['sort_by'] = 'VALUE';
        $valueParams['sort_order'] = ($sortBy === 'VALUE' && $sortOrder === 'ASC') ? 'DESC' : 'ASC';
        unset($valueParams['PAGEN_CURRENCY_NAV']); // Сброс пагинации при смене сортировки
        
        $this->arResult['SORT_LINKS'] = [
            'NAME' => $currentUrl . '?' . http_build_query($nameParams),
            'VALUE' => $currentUrl . '?' . http_build_query($valueParams),
        ];
        
        // Добавляем отладочную информацию (если включена)
        if ($arParams['SHOW_DEBUG_INFO'] === 'Y') {
            $this->arResult['DEBUG'] = [
                'TOTAL_COUNT' => $totalCount,
                'PAGE_SIZE' => $pageSize,
                'CURRENT_PAGE' => $currentPage,
                'PAGE_COUNT' => $pageCount,
                'OFFSET' => $offset,
                'GET_PARAMS' => $_GET
            ];
        }
    }
}

$this->includeComponentTemplate();