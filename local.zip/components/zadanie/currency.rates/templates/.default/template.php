<?php if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die(); ?>

<div class="currency-rates">
    <h3>Курсы валют ЦБ РФ</h3>
    
    <?php if (!empty($arResult['ERROR'])): ?>
        <div class="currency-error">
            <p style="color: red;"><?= htmlspecialchars($arResult['ERROR']) ?></p>
        </div>
    <?php endif; ?>
    
    <?php if (!empty($arResult['CURRENCIES'])): ?>
        
        <!-- Панель сортировки -->
        <div class="currency-sort-panel" style="margin-bottom: 20px; padding: 10px; background: #f5f5f5; border-radius: 5px;">
            <span>Сортировать по: </span>
            <a href="<?= htmlspecialchars($arResult['SORT_LINKS']['NAME']) ?>" 
               class="sort-link <?= $arResult['SORT_BY'] === 'NAME' ? 'active' : '' ?>"
               style="margin-right: 15px; text-decoration: none; <?= $arResult['SORT_BY'] === 'NAME' ? 'font-weight: bold;' : '' ?>">
                Алфавиту 
                <?php if ($arResult['SORT_BY'] === 'NAME'): ?>
                    <?= $arResult['SORT_ORDER'] === 'ASC' ? '↑' : '↓' ?>
                <?php endif; ?>
            </a>
            <a href="<?= htmlspecialchars($arResult['SORT_LINKS']['VALUE']) ?>" 
               class="sort-link <?= $arResult['SORT_BY'] === 'VALUE' ? 'active' : '' ?>"
               style="text-decoration: none; <?= $arResult['SORT_BY'] === 'VALUE' ? 'font-weight: bold;' : '' ?>">
                Курсу 
                <?php if ($arResult['SORT_BY'] === 'VALUE'): ?>
                    <?= $arResult['SORT_ORDER'] === 'ASC' ? '↑' : '↓' ?>
                <?php endif; ?>
            </a>
        </div>
        
        <!-- Информация о количестве и текущей странице -->
        <div class="currency-info" style="margin-bottom: 15px; color: #666;">
            Всего валют: <?= $arResult['ELEMENTS_COUNT'] ?>
            <?php if ($arResult['PAGE_COUNT'] > 1): ?>
                | Страница <?= $arResult['CURRENT_PAGE'] ?> из <?= $arResult['PAGE_COUNT'] ?>
            <?php endif; ?>
        </div>
        
        <!-- Отладочная информация -->
        <?php if (!empty($arResult['DEBUG'])): ?>
            <div style="background: #ffffcc; padding: 10px; margin-bottom: 10px; font-size: 12px;">
                <strong>Debug info:</strong><br>
                Total: <?= $arResult['DEBUG']['TOTAL_COUNT'] ?>, 
                Page Size: <?= $arResult['DEBUG']['PAGE_SIZE'] ?>, 
                Current Page: <?= $arResult['DEBUG']['CURRENT_PAGE'] ?>, 
                Page Count: <?= $arResult['DEBUG']['PAGE_COUNT'] ?>,
                Offset: <?= $arResult['DEBUG']['OFFSET'] ?><br>
                GET params: <?= htmlspecialchars(json_encode($arResult['DEBUG']['GET_PARAMS'])) ?>
            </div>
        <?php endif; ?>
        
        <!-- Список валют -->
        <div class="currency-list">
            <?php foreach ($arResult['CURRENCIES'] as $currency): ?>
                <div class="currency-item" style="display: flex; justify-content: space-between; align-items: center; padding: 10px; border-bottom: 1px solid #eee;">
                    <div class="currency-name" style="flex: 1;">
                        <strong><?= htmlspecialchars($currency['NAME']) ?></strong>
                        <?php if (!empty($currency['CODE'])): ?>
                            <span class="currency-code" style="color: #666; margin-left: 5px;">(<?= htmlspecialchars($currency['CODE']) ?>)</span>
                        <?php endif; ?>
                    </div>
                    <div class="currency-value" style="flex: 0 0 150px; text-align: right;">
                        <span class="nominal"><?= intval($currency['NOMINAL']) ?></span> = 
                        <span class="rate" style="font-weight: bold;"><?= number_format(floatval($currency['VALUE']), 4, ',', ' ') ?> ₽</span>
                    </div>
                    <div class="currency-change <?= floatval($currency['CHANGE']) >= 0 ? 'positive' : 'negative' ?>" 
                         style="flex: 0 0 100px; text-align: right; <?= floatval($currency['CHANGE']) >= 0 ? 'color: green;' : 'color: red;' ?>">
                        <?= floatval($currency['CHANGE']) >= 0 ? '+' : '' ?><?= number_format(floatval($currency['CHANGE']), 4, ',', ' ') ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Пагинация -->
        <?php if ($arResult['PAGE_COUNT'] > 1): ?>
            <div class="currency-pagination" style="margin-top: 20px; text-align: center;">
                <?php
                // Простая навигация
                $currentPage = $arResult['CURRENT_PAGE'];
                $pageCount = $arResult['PAGE_COUNT'];
                
                echo '<div class="simple-pagination">';
                
                // Кнопка "Предыдущая"
                if ($currentPage > 1) {
                    $prevPage = $currentPage - 1;
                    $currentParams = $_GET;
                    $currentParams['PAGEN_CURRENCY_NAV'] = $prevPage;
                    echo '<a href="?' . http_build_query($currentParams) . '">« Предыдущая</a> ';
                }
                
                // Номера страниц
                for ($i = 1; $i <= $pageCount; $i++) {
                    if ($i == $currentPage) {
                        echo '<strong>' . $i . '</strong> ';
                    } else {
                        $currentParams = $_GET;
                        $currentParams['PAGEN_CURRENCY_NAV'] = $i;
                        echo '<a href="?' . http_build_query($currentParams) . '">' . $i . '</a> ';
                    }
                }
                
                // Кнопка "Следующая"
                if ($currentPage < $pageCount) {
                    $nextPage = $currentPage + 1;
                    $currentParams = $_GET;
                    $currentParams['PAGEN_CURRENCY_NAV'] = $nextPage;
                    echo '<a href="?' . http_build_query($currentParams) . '">Следующая »</a>';
                }
                
                echo '</div>';
                ?>
            </div>
        <?php endif; ?>
        
    <?php else: ?>
        <div class="currency-empty">
            <p>Данные о курсах валют отсутствуют.</p>
        </div>
    <?php endif; ?>
</div>