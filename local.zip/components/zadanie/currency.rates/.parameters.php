<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arComponentParameters = array(
    "GROUPS" => array(
        "SETTINGS" => array(
            "NAME" => "Настройки отображения"
        ),
        "PAGINATION" => array(
            "NAME" => "Настройки пагинации"
        ),
        "SORTING" => array(
            "NAME" => "Настройки сортировки"
        ),
    ),
    "PARAMETERS" => array(
        "CACHE_TIME" => array(
            "DEFAULT" => 3600,
        ),
        "ELEMENTS_PER_PAGE" => array(
            "PARENT" => "PAGINATION",
            "NAME" => "Количество элементов на странице",
            "TYPE" => "LIST",
            "VALUES" => array(
                "10" => "10",
                "20" => "20",
                "30" => "30",
                "50" => "50",
                "100" => "100",
            ),
            "DEFAULT" => "20",
        ),
        "DEFAULT_SORT_BY" => array(
            "PARENT" => "SORTING",
            "NAME" => "Поле сортировки по умолчанию",
            "TYPE" => "LIST",
            "VALUES" => array(
                "NAME" => "По названию",
                "VALUE" => "По курсу",
            ),
            "DEFAULT" => "NAME",
        ),
        "DEFAULT_SORT_ORDER" => array(
            "PARENT" => "SORTING",
            "NAME" => "Порядок сортировки по умолчанию",
            "TYPE" => "LIST",
            "VALUES" => array(
                "ASC" => "По возрастанию",
                "DESC" => "По убыванию",
            ),
            "DEFAULT" => "ASC",
        ),
        "SHOW_DEBUG_INFO" => array(
            "PARENT" => "SETTINGS",
            "NAME" => "Показывать отладочную информацию",
            "TYPE" => "CHECKBOX",
            "DEFAULT" => "N",
        ),
    ),
);
?>